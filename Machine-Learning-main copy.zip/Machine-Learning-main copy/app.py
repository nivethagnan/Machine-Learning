from flask import Flask, render_template, request, jsonify
import requests
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from sklearn.model_selection import learning_curve
from sklearn.neighbors import KNeighborsRegressor
from sklearn.metrics import mean_absolute_error
import matplotlib.pyplot as plt
from sklearn.cluster import KMeans

app = Flask(__name__)

# Load the data into a pandas dataframe
df = pd.read_csv('/Users/rodabaebadi/Desktop/Machine-Learning-main copy/household_power_consumption.txt', delimiter=';',
                 parse_dates={'dt' :[0,1]}, infer_datetime_format=True,
                 na_values=['nan','?'], index_col='dt')

# Resample the data to hourly intervals
df = df.resample('1H').mean()

# Remove any missing values
df.dropna(inplace=True)

# Create a dataframe for the target variable (global_active_power)
y = df['Global_active_power'].values.reshape(-1,1)
y_reactive = df['Global_reactive_power'].values.reshape(-1,1)
# Create a dataframe for the predictor variables (voltage, global_reactive_power, etc.)
X = df.drop('Global_active_power', axis=1).values
X_reactive = df.drop('Global_reactive_power', axis=1).values

# Split the data into training and testing sets
train_size = int(0.8 * len(df))
X_train, X_test = X[:train_size], X[train_size:]
y_train, y_test = y[:train_size], y[train_size:]

train_size_reactive = int(0.8 * len(df))
X_reactive_train, X_reactive_test = X_reactive[:train_size_reactive], X_reactive[train_size_reactive:]
y_reactive_train, y_reactive_test = y_reactive[:train_size_reactive], y_reactive[train_size_reactive:]

knn_2 = KNeighborsRegressor(n_neighbors=20)
knn_2.fit(X_reactive_train, y_reactive_train)
# Train a KNN model to predict the global active power consumption
knn = KNeighborsRegressor(n_neighbors=20)
knn.fit(X_train, y_train)
y_reactive_pred = knn_2.predict(X_reactive_test)
# Use the trained KNN model to predict the global active power consumption
y_pred = knn.predict(X_test)




individual_power_2 = knn_2.predict(X_reactive)
# Use the trained KNN model to disaggregate the global active power consumption into individual appliance consumption
individual_power = knn.predict(X)
df['Individual_appliance_power_2'] = individual_power_2
# Add the disaggregated individual appliance consumption to the dataframe
df['Individual_appliance_power'] = individual_power
mean_energy_2 = np.mean(y_reactive_pred, axis=1)
# Identify the predicted appliances that use the most energy
mean_energy = np.mean(y_pred, axis=1)
# Create dictionary to store mean energy consumption for each appliance
appliance_energy = {
    'sub_metering_1': mean_energy[0],
    'sub_metering_2': mean_energy[1],
    'sub_metering_3': mean_energy[2]
}
sorted_appliances = sorted(appliance_energy.items(), key=lambda x: x[1], reverse=True)


def get_appliance_usage():
    laundry_df = df[['Sub_metering_2']].copy()
    laundry_df['hour'] = laundry_df.index.hour
    laundry_df['day'] = laundry_df.index.dayofweek
    laundry_by_hour_day = laundry_df.groupby(['hour', 'day']).mean()
    max_hour, max_day = laundry_by_hour_day['Sub_metering_2'].idxmax()

    return f"The laundry appliances are used the most on {laundry_by_hour_day.index.names[1]} {max_day} at {max_hour}:00"
def get_appliance_usage1():
    kitchen_df = df[['Sub_metering_1']].copy()
    kitchen_df['hour'] = kitchen_df.index.hour
    kitchen_df['day'] = kitchen_df.index.dayofweek
    kitchen_by_hour_day = kitchen_df.groupby(['hour', 'day']).mean()
    max_hour1, max_day1 = kitchen_by_hour_day['Sub_metering_1'].idxmax()

    return f"The kitchen appliances are used the most on {kitchen_by_hour_day.index.names[1]} {max_day1} at {max_hour1}:00"
def get_appliance_usage2():
    acheater_df = df[['Sub_metering_3']].copy()
    acheater_df['hour'] = acheater_df.index.hour
    acheater_df['day'] = acheater_df.index.dayofweek
    acheater_by_hour_day = acheater_df.groupby(['hour', 'day']).mean()
    max_hour2, max_day2 = acheater_by_hour_day['Sub_metering_3'].idxmax()

    return f"The AC/Heater appliances are used the most on {acheater_by_hour_day.index.names[1]} {max_day2} at {max_hour2}:00"

def meanerror():
   mae = mean_absolute_error(y_test, y_pred)
   return mae
def mean_error_2():
    mae_2 = mean_absolute_error(y_reactive_test, y_reactive_pred)
    return mae_2
# def plot_learning_curve(model, X_train, y_train, X_test, y_test):
#     train_sizes, train_scores, test_scores = learning_curve(model, X_train, y_train, cv=5, scoring='neg_mean_absolute_error')
#     train_scores_mean = -np.mean(train_scores, axis=1)
#     test_scores_mean = -np.mean(test_scores, axis=1)
#     plt.plot(train_sizes, train_scores_mean, label='Training error')
#     plt.plot(train_sizes, test_scores_mean, label='Validation error')
#     plt.xlabel('Number of training examples')
#     plt.ylabel('Mean absolute error')
#     plt.title('Learning curve')
#     plt.legend(loc='best')
#     plt.show()
#
#     if train_scores_mean[-1] > test_scores_mean[-1]:
#         print("Model is overfitting")
#     elif train_scores_mean[-1] < test_scores_mean[-1]:
#         print("Model is underfitting")
#     else:
#         print("Model is neither overfitting nor underfitting")
#
#     return plt




@app.route('/data/<appliance>')
def data(appliance):
    global sorted_appliances
    mean_energy_dict = dict(sorted_appliances)

    if appliance in mean_energy_dict:

        return jsonify(mean_energy_dict[appliance])

    else:
        return "Appliance not found"


@app.route('/', methods=['GET', 'POST'])

def home():
    global sorted_appliances
    cost_per_kwh = 0.0
    usage_hours = 0.0
    error = meanerror()
    error_1 = mean_error_2()




    if request.method == 'POST':

        sub_metering_1 = requests.get('http://localhost:5000/data/sub_metering_1').text
        sub_metering_2 = requests.get('http://localhost:5000/data/sub_metering_2').text
        sub_metering_3 = requests.get('http://localhost:5000/data/sub_metering_3').text
        sub_metering_1_1 = requests.get('http://localhost:5000/data/sub_metering_1_1').text
        y_pred = knn.predict(X_test)
        cost_per_kwh = float(request.form['cost_per_kwh'])
        usage_hours = float(request.form['usage_hours'])
        hour_day_2 = get_appliance_usage()
        hour_day_1 = get_appliance_usage1()
        hour_day_3 = get_appliance_usage2()

        #plot_learning_curve(knn, X_train, y_train, X_test, y_test)
        sub_metering_1_cost = round((float(sub_metering_1) * cost_per_kwh * usage_hours) / 100, 2)
        sub_metering_2_cost = round((float(sub_metering_2) * cost_per_kwh * usage_hours) / 100, 2)
        sub_metering_3_cost = round(float(sub_metering_3) * cost_per_kwh * usage_hours / 1009, 2)
        sub_metering_1_cost2 = requests.get('http://localhost:5000/data/sub_metering_1_cost').text
        sub_metering_2_cost2 = requests.get('http://localhost:5000/data/sub_metering_2_cost').text
        sub_metering_3_cost2 = requests.get('http://localhost:5000/data/sub_metering_3_cost').text
        selected_option = request.form['dd-appliance']
        return render_template('home.html', sub_metering_1_1=sub_metering_1_1,sub_metering_1=sub_metering_1, sub_metering_2=sub_metering_2, sub_metering_3=sub_metering_3, sub_metering_1_cost=sub_metering_1_cost, sub_metering_2_cost=sub_metering_2_cost, sub_metering_3_cost=sub_metering_3_cost, error=error, error_1=error_1, hour_day_2=hour_day_2, hour_day_1=hour_day_1, hour_day_3=hour_day_3, selected_option=selected_option)
    else:
       return render_template('home.html')




if __name__ == '__main__':
    app.run(debug=True)